package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;

public class Controller {

    @FXML
    private TextField textField;

    @FXML
    private ToggleGroup a;

    @FXML
    void AfficherDetail(ActionEvent event) {

    }

    @FXML
    void AjouterArc(ActionEvent event) {

    }

    @FXML
    void AjouterNoeud(ActionEvent event) {

    }

    @FXML
    void AjouterPaquet(ActionEvent event) {

    }

    @FXML
    void FluxAleatoire(ActionEvent event) {

    }

    @FXML
    void Navigation(ActionEvent event) {

    }

    @FXML
    void ReseauRoutier(ActionEvent event) {

    }

    @FXML
    void ReseauSocial(ActionEvent event) {

    }

    @FXML
    void ReseauWeb(ActionEvent event) {

    }

    @FXML
    void Reset(ActionEvent event) {

    }

    @FXML
    void SupprimerArc(ActionEvent event) {

    }

    @FXML
    void SupprimerNoeud(ActionEvent event) {

    }

    @FXML
    void SupprimerPaquet(ActionEvent event) {

    }

    @FXML
    void Zoom(ActionEvent event) {

    }

    @FXML
    void openNewStage(ActionEvent event){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("sample/second_view.fxml"));
            Parent root = (Parent) loader.load();
            SecondController secController = loader.getController();
            secController.myFunction(textField.getText());
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
}

